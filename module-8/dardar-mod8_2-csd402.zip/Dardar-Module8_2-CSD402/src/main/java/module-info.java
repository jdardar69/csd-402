module com.example.dardarmodule8_2csd402 {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.dardarmodule8_2csd402 to javafx.fxml;
    exports com.example.dardarmodule8_2csd402;
}